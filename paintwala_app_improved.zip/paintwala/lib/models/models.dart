enum UserRole { customer, painter, shop }

class LatLng {
  final double lat;
  final double lng;
  const LatLng(this.lat, this.lng);
}

class Area {
  final String name;
  final LatLng point;
  const Area(this.name, this.point);
}

class Painter {
  final String id;
  final String name;
  final String areaName;
  final LatLng point;
  final double rating;
  final int years;
  final List<String> services;
  final int ratePerSqft;
  bool approved;
  final String? phone;
  Painter({
    required this.id,
    required this.name,
    required this.areaName,
    required this.point,
    required this.rating,
    required this.years,
    required this.services,
    required this.ratePerSqft,
    this.approved = false,
    this.phone,
  });
}

class Product {
  final String name;
  final String brand;
  final String type;
  final String size;
  final int price;
  const Product(this.name, this.brand, this.type, this.size, this.price);
}

class Shop {
  final String id;
  final String name;
  final String areaName;
  final String hours;
  final LatLng point;
  final List<String> brands;
  final List<Product> products;
  final String? phone;
  Shop({
    required this.id,
    required this.name,
    required this.areaName,
    required this.hours,
    required this.point,
    required this.brands,
    required this.products,
    this.phone,
  });
}

class Booking {
  final String id;
  final String service;
  final String propertyType;
  final int sqft;
  final String areaName;
  final DateTime date;
  final String notes;
  final String? providerName;
  String status;
  Booking({
    required this.id,
    required this.service,
    required this.propertyType,
    required this.sqft,
    required this.areaName,
    required this.date,
    required this.notes,
    this.providerName,
    this.status = 'Requested',
  });
}

class Quote {
  final String painterId;
  final int amount;
  final int days;
  final String notes;
  const Quote(this.painterId, this.amount, this.days, this.notes);
}
