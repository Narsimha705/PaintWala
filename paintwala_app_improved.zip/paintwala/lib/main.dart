import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/screens/welcome_screen.dart';
import 'package:paintwala/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await appState.loadLang();
  runApp(const PaintWalaApp());
}

class PaintWalaApp extends StatelessWidget {
  const PaintWalaApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => MaterialApp(
          title: 'PaintWala',
          debugShowCheckedModeBanner: false,
          theme: buildTheme(),
          locale: Locale(appState.lang),
          supportedLocales: const [Locale('en'), Locale('te'), Locale('hi')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const WelcomeScreen(),
        ),
      );
}
