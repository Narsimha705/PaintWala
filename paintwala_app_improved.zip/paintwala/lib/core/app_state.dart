import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:paintwala/data/repository.dart';
import 'package:paintwala/data/sample_repository.dart';
import 'package:paintwala/models/models.dart';

/// Selected role, location and distance filter.
class AppState extends ChangeNotifier {
  static const radii = [2, 5, 10, 20];
  UserRole? role;
  LatLng? point;
  String? label;
  int radiusKm = 5;
  String lang = 'en';

  Future<void> loadLang() async {
    try {
      final p = await SharedPreferences.getInstance();
      lang = p.getString('lang') ?? 'en';
    } catch (_) {}
  }

  void setLang(String l) {
    lang = l;
    notifyListeners();
    _saveLang(l);
  }

  Future<void> _saveLang(String l) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('lang', l);
    } catch (_) {}
  }

  void setLocation(LatLng p, String l) {
    point = p;
    label = l;
    notifyListeners();
  }

  void setRadius(int r) {
    radiusKm = r;
    notifyListeners();
  }
}

final appState = AppState();

/// To connect a real database, replace SampleRepository() with your
/// own implementation of PaintWalaRepository (Firebase, Supabase, REST...).
final PaintWalaRepository repository = SampleRepository();
