import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:geolocator/geolocator.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/models/models.dart';

class LocationService {
  /// Asks the user first, then asks the OS. Returns true if location was set.
  static Future<bool> requestAndSet(BuildContext context) async {
    final agreed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr(context, 'Use your location?')),
        content: Text(tr(context, 'PaintWala uses your location only to show painters and paint shops near you. You can also pick your area manually.')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(tr(context, 'Not now'))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(tr(context, 'Allow'))),
        ],
      ),
    );
    if (agreed != true) return false;
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return false;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return false;
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: LocationSettings(
          accuracy: LocationAccuracy.low,
          timeLimit: Duration(seconds: 10),
        ),
      );
      appState.setLocation(
          LatLng(pos.latitude, pos.longitude), 'My current location');
      return true;
    } catch (_) {
      return false;
    }
  }
}
