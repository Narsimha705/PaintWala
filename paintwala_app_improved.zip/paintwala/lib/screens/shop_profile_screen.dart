import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/widgets/common.dart';

class ShopProfileScreen extends StatefulWidget {
  final Shop shop;
  final bool ownerMode;
  const ShopProfileScreen({super.key, required this.shop, this.ownerMode = false});
  @override
  State<ShopProfileScreen> createState() => _ShopProfileScreenState();
}

class _ShopProfileScreenState extends State<ShopProfileScreen> {
  Future<void> _addProduct() async {
    final name = TextEditingController();
    final price = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr(context, 'Add product')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: name,
              decoration: InputDecoration(labelText: tr(context, 'Product name'))),
          SizedBox(height: 12),
          TextField(
              controller: price,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: tr(context, 'Price (Rs)'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr(context, 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr(context, 'Add'))),
        ],
      ),
    );
    final amount = int.tryParse(price.text) ?? 0;
    if (ok == true && name.text.trim().isNotEmpty && amount > 0) {
      await repository.addProduct(widget.shop.id,
          Product(name.text.trim(), 'Sample Brand', 'Other', '-', amount));
      if (mounted) setState(() {});
    }
    name.dispose();
    price.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.shop;
    return Scaffold(
      appBar: AppBar(title: Text(widget.ownerMode ? tr(context, 'My shop (sample)') : s.name)),
      floatingActionButton: widget.ownerMode
          ? FloatingActionButton.extended(
              backgroundColor: AppColors.orange,
              foregroundColor: Colors.white,
              onPressed: _addProduct,
              icon: Icon(Icons.add),
              label: Text(tr(context, 'Add product')))
          : null,
      body: ListView(padding: EdgeInsets.all(16), children: [
        SampleDataBanner(),
        Card(
          color: Colors.white,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.name,
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.navy)),
              SizedBox(height: 4),
              Text('${s.areaName} · ${tr(context, 'Open')} ${s.hours}'),
              SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final b in s.brands)
                  Chip(label: Text(b), visualDensity: VisualDensity.compact),
              ]),
            ]),
          ),
        ),
        SizedBox(height: 12),
        if (!widget.ownerMode) ...[
          ContactButtons(phone: s.phone),
          SizedBox(height: 12),
        ],
        Text(tr(context, 'Products'),
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        for (final p in s.products)
          Card(
            color: Colors.white,
            child: ListTile(
              leading: Icon(Icons.format_color_fill, color: AppColors.orange),
              title: Text(p.name),
              subtitle: Text('${p.brand} · ${p.type} · ${p.size}'),
              trailing: Text('Rs ${p.price}',
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        SizedBox(height: 72),
      ]),
    );
  }
}
