import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/core/geo.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/screens/painter_profile_screen.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/widgets/common.dart';

class PaintersListScreen extends StatelessWidget {
  const PaintersListScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(tr(context, 'Nearby painters'))),
        body: ListenableBuilder(
          listenable: appState,
          builder: (context, _) => ListView(padding: EdgeInsets.all(16), children: [
            SampleDataBanner(),
            LocationFilter(),
            FutureBuilder<List<Painter>>(
              future: repository.painters(),
              builder: (context, snap) {
                final origin = appState.point;
                if (origin == null) {
                  return EmptyState('Set your location above to see nearby painters.');
                }
                if (!snap.hasData) {
                  return Center(child: CircularProgressIndicator());
                }
                final items = [
                  for (final p in snap.data!.where((p) => p.approved))
                    (p, distanceKm(origin, p.point)),
                ].where((e) => e.$2 <= appState.radiusKm).toList()
                  ..sort((a, b) => a.$2.compareTo(b.$2));
                if (items.isEmpty) {
                  return EmptyState(tr(context, 'No approved sample painters within {n} km. Try a larger distance.', {'n': '${appState.radiusKm}'}));
                }
                return Column(children: [
                  for (final (p, km) in items)
                    Card(
                      color: Colors.white,
                      child: ListTile(
                        leading: CircleAvatar(
                            backgroundColor: AppColors.navy,
                            child: Icon(Icons.brush, color: Colors.white)),
                        title: Text(p.name),
                        subtitle: Text(
                            '${p.areaName} · ${km.toStringAsFixed(1)} ${tr(context, 'km')} · ★ ${p.rating}\n${tr(context, 'SAMPLE')} · Rs ${p.ratePerSqft}/${tr(context, 'sq ft')}'),
                        isThreeLine: true,
                        trailing: Icon(Icons.chevron_right, color: AppColors.orange),
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => PainterProfileScreen(painter: p))),
                      ),
                    ),
                ]);
              },
            ),
          ]),
        ),
      );
}
