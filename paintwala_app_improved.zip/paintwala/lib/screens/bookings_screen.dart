import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/widgets/common.dart';

class BookingsScreen extends StatelessWidget {
  const BookingsScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(tr(context, 'My bookings'))),
        body: FutureBuilder<List<Booking>>(
          future: repository.bookings(),
          builder: (context, snap) {
            if (!snap.hasData) return Center(child: CircularProgressIndicator());
            if (snap.data!.isEmpty) {
              return EmptyState('No bookings yet. Submit a painting request to see it here.');
            }
            return ListView(padding: EdgeInsets.all(16), children: [
              for (final b in snap.data!)
                Card(
                  color: Colors.white,
                  child: ListTile(
                    title: Text('${b.service} · ${b.propertyType}'),
                    subtitle: Text(
                        '${b.areaName} · ${b.sqft} ${tr(context, 'sq ft')}\n${tr(context, 'Start')}: ${fmtDate(b.date)}'
                        '${b.providerName != null ? '\n${tr(context, 'Painter')}: ${b.providerName}' : ''}'),
                    isThreeLine: true,
                    trailing: StatusChip(b.status),
                  ),
                ),
            ]);
          },
        ),
      );
}
