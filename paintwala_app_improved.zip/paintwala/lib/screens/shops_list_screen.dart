import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/core/geo.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/screens/shop_profile_screen.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/widgets/common.dart';

class ShopsListScreen extends StatelessWidget {
  const ShopsListScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(tr(context, 'Nearby paint shops'))),
        body: ListenableBuilder(
          listenable: appState,
          builder: (context, _) => ListView(padding: EdgeInsets.all(16), children: [
            SampleDataBanner(),
            LocationFilter(),
            FutureBuilder<List<Shop>>(
              future: repository.shops(),
              builder: (context, snap) {
                final origin = appState.point;
                if (origin == null) {
                  return EmptyState('Set your location above to see nearby paint shops.');
                }
                if (!snap.hasData) {
                  return Center(child: CircularProgressIndicator());
                }
                final items = [
                  for (final s in snap.data!)
                    (s, distanceKm(origin, s.point)),
                ].where((e) => e.$2 <= appState.radiusKm).toList()
                  ..sort((a, b) => a.$2.compareTo(b.$2));
                if (items.isEmpty) {
                  return EmptyState(tr(context, 'No sample shops within {n} km. Try a larger distance.', {'n': '${appState.radiusKm}'}));
                }
                return Column(children: [
                  for (final (s, km) in items)
                    Card(
                      color: Colors.white,
                      child: ListTile(
                        leading: CircleAvatar(
                            backgroundColor: AppColors.navy,
                            child: Icon(Icons.storefront, color: Colors.white)),
                        title: Text(s.name),
                        subtitle: Text(
                            '${s.areaName} · ${km.toStringAsFixed(1)} ${tr(context, 'km')} · ${s.hours}\n${tr(context, 'SAMPLE')}'),
                        isThreeLine: true,
                        trailing: Icon(Icons.chevron_right, color: AppColors.orange),
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => ShopProfileScreen(shop: s))),
                      ),
                    ),
                ]);
              },
            ),
          ]),
        ),
      );
}
