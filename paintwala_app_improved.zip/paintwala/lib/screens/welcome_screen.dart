import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/screens/admin_screen.dart';
import 'package:paintwala/screens/customer_home_screen.dart';
import 'package:paintwala/screens/painter_profile_screen.dart';
import 'package:paintwala/screens/shop_profile_screen.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/widgets/common.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  void _push(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  Future<void> _selectRole(BuildContext c, UserRole role) async {
    appState.role = role;
    switch (role) {
      case UserRole.customer:
        _push(c, CustomerHomeScreen());
      case UserRole.painter:
        final p = (await repository.painters()).first;
        if (c.mounted) _push(c, PainterProfileScreen(painter: p, ownerMode: true));
      case UserRole.shop:
        final s = (await repository.shops()).first;
        if (c.mounted) _push(c, ShopProfileScreen(shop: s, ownerMode: true));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: EdgeInsets.all(20), children: [
            SizedBox(height: 24),
            Align(alignment: Alignment.centerRight, child: LanguageButton()),
            Icon(Icons.format_paint, size: 64, color: AppColors.orange),
            SizedBox(height: 8),
            Text(tr(context, 'PaintWala'),
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: AppColors.navy)),
            Text(tr(context, 'House painting services, made simple'),
                textAlign: TextAlign.center),
            SizedBox(height: 24),
            SampleDataBanner(),
            Text(tr(context, 'Continue as'),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            _RoleCard(Icons.home_work, 'Customer', 'Find painters and paint shops',
                () => _selectRole(context, UserRole.customer)),
            _RoleCard(Icons.brush, 'Painter', 'Show your profile and send quotes',
                () => _selectRole(context, UserRole.painter)),
            _RoleCard(Icons.storefront, 'Paint Shop', 'List your paints and products',
                () => _selectRole(context, UserRole.shop)),
            SizedBox(height: 12),
            TextButton(
                onPressed: () => _push(context, AdminScreen()),
                child: Text(tr(context, 'Admin dashboard (prototype)'))),
          ]),
        ),
      );
}

class _RoleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _RoleCard(this.icon, this.title, this.subtitle, this.onTap);
  @override
  Widget build(BuildContext context) => Card(
        color: Colors.white,
        child: ListTile(
          leading: CircleAvatar(
              backgroundColor: AppColors.navy, child: Icon(icon, color: Colors.white)),
          title: Text(tr(context, title), style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(tr(context, subtitle)),
          trailing: Icon(Icons.chevron_right, color: AppColors.orange),
          onTap: onTap,
        ),
      );
}
