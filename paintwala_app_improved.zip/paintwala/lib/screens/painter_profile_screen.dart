import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/screens/request_service_screen.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/widgets/common.dart';

/// Customer view: profile + "Request this painter".
/// Painter view (ownerMode): profile + quote form.
class PainterProfileScreen extends StatefulWidget {
  final Painter painter;
  final bool ownerMode;
  const PainterProfileScreen(
      {super.key, required this.painter, this.ownerMode = false});
  @override
  State<PainterProfileScreen> createState() => _PainterProfileScreenState();
}

class _PainterProfileScreenState extends State<PainterProfileScreen> {
  final _form = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _days = TextEditingController();
  final _notes = TextEditingController();

  @override
  void dispose() {
    _amount.dispose();
    _days.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _sendQuote() async {
    if (!_form.currentState!.validate()) return;
    await repository.addQuote(Quote(widget.painter.id, int.parse(_amount.text),
        int.parse(_days.text), _notes.text.trim()));
    _amount.clear();
    _days.clear();
    _notes.clear();
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(tr(context, 'Sample quote saved (not sent to anyone).'))));
  }

  String? _positive(String? v) =>
      (int.tryParse(v ?? '') ?? 0) > 0 ? null : tr(context, 'Enter a valid number');

  @override
  Widget build(BuildContext context) {
    final p = widget.painter;
    return Scaffold(
      appBar: AppBar(title: Text(widget.ownerMode ? tr(context, 'My profile (sample)') : p.name)),
      body: ListView(padding: EdgeInsets.all(16), children: [
        SampleDataBanner(),
        Card(
          color: Colors.white,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name,
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.navy)),
              SizedBox(height: 4),
              Text('${p.areaName} · ★ ${p.rating} · ${p.years} ${tr(context, 'yrs experience')}'),
              Text(tr(context, 'Approx. Rs {n} per sq ft (sample)', {'n': '${p.ratePerSqft}'})),
              SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                for (final s in p.services)
                  Chip(label: Text(tr(context, s)), visualDensity: VisualDensity.compact),
              ]),
            ]),
          ),
        ),
        SizedBox(height: 12),
        if (!widget.ownerMode) ...[
          ContactButtons(phone: p.phone),
          SizedBox(height: 12),
          EstimateCard(rate: p.ratePerSqft),
          SizedBox(height: 12),
        ],
        if (!widget.ownerMode)
          ElevatedButton(
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => RequestServiceScreen(painter: p))),
            child: Text(tr(context, 'Request this painter')),
          )
        else ...[
          Text(tr(context, 'Send a quote'),
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Form(
            key: _form,
            child: Column(children: [
              TextFormField(
                controller: _amount,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: tr(context, 'Total amount (Rs)')),
                validator: _positive,
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _days,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: tr(context, 'Days needed')),
                validator: _positive,
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _notes,
                maxLines: 2,
                decoration: InputDecoration(labelText: tr(context, 'Notes (materials, terms)')),
              ),
              SizedBox(height: 12),
              ElevatedButton(onPressed: _sendQuote, child: Text(tr(context, 'Send quote'))),
            ]),
          ),
          SizedBox(height: 16),
          Text(tr(context, 'Quotes sent (this session)'),
              style: TextStyle(fontWeight: FontWeight.bold)),
          FutureBuilder<List<Quote>>(
            future: repository.quotes(),
            builder: (context, snap) {
              final mine = (snap.data ?? [])
                  .where((q) => q.painterId == p.id)
                  .toList();
              if (mine.isEmpty) return EmptyState('No quotes yet.');
              return Column(children: [
                for (final q in mine)
                  Card(
                    color: Colors.white,
                    child: ListTile(
                      title: Text('Rs ${q.amount} · ${q.days} ${tr(context, 'days')}'),
                      subtitle: Text(q.notes.isEmpty ? tr(context, 'No notes') : q.notes),
                    ),
                  ),
              ]);
            },
          ),
        ],
      ]),
    );
  }
}
