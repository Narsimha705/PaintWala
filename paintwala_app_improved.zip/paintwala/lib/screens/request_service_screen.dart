import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/screens/bookings_screen.dart';
import 'package:paintwala/widgets/common.dart';

class RequestServiceScreen extends StatefulWidget {
  final Painter? painter;
  const RequestServiceScreen({super.key, this.painter});
  @override
  State<RequestServiceScreen> createState() => _RequestServiceScreenState();
}

class _RequestServiceScreenState extends State<RequestServiceScreen> {
  final _form = GlobalKey<FormState>();
  final _sqft = TextEditingController();
  final _notes = TextEditingController();
  String _service = 'Interior painting';
  String _property = '2 BHK';
  DateTime _date = DateTime.now().add(Duration(days: 3));

  @override
  void dispose() {
    _sqft.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date.isBefore(DateTime.now()) ? DateTime.now() : _date,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (d != null) setState(() => _date = d);
  }

  Future<void> _submit() async {
    if (appState.label == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr(context, 'Please set your location first.'))));
      return;
    }
    if (!_form.currentState!.validate()) return;
    await repository.addBooking(Booking(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      service: _service,
      propertyType: _property,
      sqft: int.parse(_sqft.text),
      areaName: appState.label!,
      date: _date,
      notes: _notes.text.trim(),
      providerName: widget.painter?.name,
    ));
    if (!mounted) return;
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => BookingsScreen()));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(tr(context, 'Request painting service'))),
        body: Form(
          key: _form,
          child: ListView(padding: EdgeInsets.all(16), children: [
            if (widget.painter != null)
              Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: Text('${tr(context, 'Requesting')}: ${widget.painter!.name} (${tr(context, 'sample')})',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            LocationFilter(),
            DropdownButtonFormField<String>(
              value: _service,
              decoration: InputDecoration(labelText: tr(context, 'Service')),
              items: [
                'Interior painting',
                'Exterior painting',
                'Interior + exterior',
                'Waterproofing',
                'Wood / metal polish',
              ].map((e) => DropdownMenuItem(value: e, child: Text(tr(context, e)))).toList(),
              onChanged: (v) => setState(() => _service = v!),
            ),
            SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _property,
              decoration: InputDecoration(labelText: tr(context, 'Property type')),
              items: ['1 BHK', '2 BHK', '3 BHK', 'Villa', 'Shop / office']
                  .map((e) => DropdownMenuItem(value: e, child: Text(tr(context, e))))
                  .toList(),
              onChanged: (v) => setState(() => _property = v!),
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _sqft,
              onChanged: (_) => setState(() {}),
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: tr(context, 'Approx. area (sq ft)')),
              validator: (v) => (int.tryParse(v ?? '') ?? 0) > 0
                  ? null
                  : tr(context, 'Enter a valid area'),
            ),
            if (widget.painter != null && (int.tryParse(_sqft.text) ?? 0) > 0)
              Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                    '${tr(context, 'Estimated cost')}: ${estimateText(int.parse(_sqft.text), widget.painter!.ratePerSqft)} (${tr(context, 'sample')})',
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            SizedBox(height: 12),
            ListTile(
              tileColor: Colors.white,
              leading: Icon(Icons.calendar_today),
              title: Text('${tr(context, 'Preferred start date')}: ${fmtDate(_date)}'),
              onTap: _pickDate,
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              maxLines: 3,
              decoration: InputDecoration(labelText: tr(context, 'Notes (optional)')),
            ),
            SizedBox(height: 16),
            ElevatedButton(onPressed: _submit, child: Text(tr(context, 'Submit request'))),
          ]),
        ),
      );
}
