import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/screens/bookings_screen.dart';
import 'package:paintwala/screens/painters_list_screen.dart';
import 'package:paintwala/screens/request_service_screen.dart';
import 'package:paintwala/screens/shops_list_screen.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/widgets/common.dart';

class CustomerHomeScreen extends StatelessWidget {
  const CustomerHomeScreen({super.key});

  void _push(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('PaintWala'), actions: [LanguageButton()]),
        body: ListView(padding: EdgeInsets.all(16), children: [
          Text(tr(context, 'What do you need?'),
              style: TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.navy)),
          SizedBox(height: 12),
          SampleDataBanner(),
          LocationFilter(),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: [
              _Tile(Icons.request_quote, 'Request painting service',
                  () => _push(context, RequestServiceScreen())),
              _Tile(Icons.brush, 'Nearby painters',
                  () => _push(context, PaintersListScreen())),
              _Tile(Icons.storefront, 'Nearby paint shops',
                  () => _push(context, ShopsListScreen())),
              _Tile(Icons.event_note, 'My bookings',
                  () => _push(context, BookingsScreen())),
            ],
          ),
        ]),
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Tile(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Ink(
          decoration: BoxDecoration(
              color: AppColors.navy, borderRadius: BorderRadius.circular(12)),
          padding: EdgeInsets.all(12),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 40, color: AppColors.orange),
            SizedBox(height: 8),
            Text(tr(context, label),
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ]),
        ),
      );
}
