import 'package:flutter/material.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/theme.dart';
import 'package:paintwala/models/models.dart';
import 'package:paintwala/widgets/common.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  List<Painter> _painters = [];
  int _shops = 0;
  int _bookings = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await repository.painters();
    final s = await repository.shops();
    final b = await repository.bookings();
    if (!mounted) return;
    setState(() {
      _painters = p;
      _shops = s.length;
      _bookings = b.length;
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(tr(context, 'Admin dashboard'))),
        body: RefreshIndicator(
          onRefresh: _load,
          child: ListView(padding: EdgeInsets.all(16), children: [
            SampleDataBanner(),
            Row(children: [
              _Stat('Painters', _painters.length),
              _Stat('Shops', _shops),
              _Stat('Bookings', _bookings),
            ]),
            SizedBox(height: 16),
            Text(tr(context, 'Painter approvals'),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            for (final p in _painters)
              Card(
                color: Colors.white,
                child: SwitchListTile(
                  activeColor: AppColors.orange,
                  title: Text(p.name),
                  subtitle: Text(tr(context, p.approved ? 'Approved' : 'Pending approval')),
                  value: p.approved,
                  onChanged: (v) async {
                    await repository.setPainterApproved(p.id, v);
                    _load();
                  },
                ),
              ),
          ]),
        ),
      );
}

class _Stat extends StatelessWidget {
  final String label;
  final int value;
  const _Stat(this.label, this.value);
  @override
  Widget build(BuildContext context) => Expanded(
        child: Card(
          color: AppColors.navy,
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Column(children: [
              Text('$value',
                  style: TextStyle(
                      color: AppColors.orange, fontSize: 28, fontWeight: FontWeight.bold)),
              Text(tr(context, label), style: TextStyle(color: Colors.white)),
            ]),
          ),
        ),
      );
}
