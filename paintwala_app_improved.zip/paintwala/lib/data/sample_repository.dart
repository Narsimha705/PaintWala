import 'package:paintwala/data/repository.dart';
import 'package:paintwala/models/models.dart';

/// Hyderabad areas for manual selection (sample list; add more as needed).
const sampleAreas = <Area>[
  Area('Ameerpet', LatLng(17.4375, 78.4483)),
  Area('Banjara Hills', LatLng(17.4126, 78.4482)),
  Area('Dilsukhnagar', LatLng(17.3688, 78.5247)),
  Area('Gachibowli', LatLng(17.4401, 78.3489)),
  Area('Kukatpally', LatLng(17.4948, 78.3996)),
  Area('LB Nagar', LatLng(17.3457, 78.5522)),
  Area('Madhapur', LatLng(17.4486, 78.3908)),
  Area('Miyapur', LatLng(17.4969, 78.3585)),
  Area('Secunderabad', LatLng(17.4399, 78.4983)),
  Area('Uppal', LatLng(17.4058, 78.5591)),
];

/// In-memory SAMPLE data. Nothing here is a real person or business.
class SampleRepository implements PaintWalaRepository {
  final List<Painter> _painters = [
    Painter(id: 'p1', name: 'Sample Painter 1', areaName: 'Kukatpally', point: const LatLng(17.4930, 78.4010), rating: 4.6, years: 8, services: ['Interior', 'Exterior'], ratePerSqft: 14, approved: true),
    Painter(id: 'p2', name: 'Sample Painter 2', areaName: 'Madhapur', point: const LatLng(17.4500, 78.3880), rating: 4.4, years: 5, services: ['Interior', 'Texture'], ratePerSqft: 16, approved: true),
    Painter(id: 'p3', name: 'Sample Painter 3', areaName: 'Gachibowli', point: const LatLng(17.4420, 78.3510), rating: 4.8, years: 12, services: ['Interior', 'Exterior', 'Waterproofing'], ratePerSqft: 18),
    Painter(id: 'p4', name: 'Sample Painter 4', areaName: 'Secunderabad', point: const LatLng(17.4410, 78.5010), rating: 4.2, years: 4, services: ['Interior'], ratePerSqft: 12, approved: true),
    Painter(id: 'p5', name: 'Sample Painter 5', areaName: 'Uppal', point: const LatLng(17.4070, 78.5580), rating: 4.5, years: 9, services: ['Exterior', 'Waterproofing'], ratePerSqft: 15),
    Painter(id: 'p6', name: 'Sample Painter 6', areaName: 'LB Nagar', point: const LatLng(17.3470, 78.5540), rating: 4.3, years: 6, services: ['Interior', 'Wood polish'], ratePerSqft: 13, approved: true),
    Painter(id: 'p7', name: 'Sample Painter 7', areaName: 'Ameerpet', point: const LatLng(17.4380, 78.4460), rating: 4.7, years: 10, services: ['Interior', 'Exterior', 'Texture'], ratePerSqft: 17, approved: true),
  ];

  static List<Product> _products(String tag) => [
        Product('Sample Interior Emulsion ($tag)', 'Sample Brand A', 'Interior', '20 L', 4200),
        Product('Sample Exterior Paint ($tag)', 'Sample Brand B', 'Exterior', '20 L', 5100),
        Product('Sample Primer ($tag)', 'Sample Brand A', 'Primer', '10 L', 1800),
        Product('Sample Wall Putty ($tag)', 'Sample Brand C', 'Putty', '20 kg', 900),
      ];

  late final List<Shop> _shops = [
    Shop(id: 's1', name: 'Sample Paint Shop 1', areaName: 'Miyapur', hours: '9 AM - 8 PM', point: const LatLng(17.4960, 78.3600), brands: ['Sample Brand A', 'Sample Brand B'], products: _products('S1')),
    Shop(id: 's2', name: 'Sample Paint Shop 2', areaName: 'Banjara Hills', hours: '10 AM - 9 PM', point: const LatLng(17.4140, 78.4460), brands: ['Sample Brand A', 'Sample Brand C'], products: _products('S2')),
    Shop(id: 's3', name: 'Sample Paint Shop 3', areaName: 'Dilsukhnagar', hours: '9 AM - 7 PM', point: const LatLng(17.3700, 78.5250), brands: ['Sample Brand B'], products: _products('S3')),
    Shop(id: 's4', name: 'Sample Paint Shop 4', areaName: 'Kukatpally', hours: '9 AM - 8 PM', point: const LatLng(17.4920, 78.3980), brands: ['Sample Brand A', 'Sample Brand B', 'Sample Brand C'], products: _products('S4')),
    Shop(id: 's5', name: 'Sample Paint Shop 5', areaName: 'Secunderabad', hours: '8 AM - 8 PM', point: const LatLng(17.4420, 78.4990), brands: ['Sample Brand C'], products: _products('S5')),
  ];

  final List<Booking> _bookings = [];
  final List<Quote> _quotes = [];

  @override
  Future<List<Painter>> painters() async => _painters;
  @override
  Future<List<Shop>> shops() async => _shops;
  @override
  Future<List<Booking>> bookings() async => _bookings.reversed.toList();
  @override
  Future<List<Quote>> quotes() async => _quotes;
  @override
  Future<void> addBooking(Booking b) async => _bookings.add(b);
  @override
  Future<void> addQuote(Quote q) async => _quotes.add(q);
  @override
  Future<void> addProduct(String shopId, Product p) async =>
      _shops.firstWhere((s) => s.id == shopId).products.add(p);
  @override
  Future<void> setPainterApproved(String id, bool v) async =>
      _painters.firstWhere((p) => p.id == id).approved = v;
}
