import 'package:paintwala/models/models.dart';

/// Data contract for the whole app. Screens only talk to this interface,
/// so a real backend can replace SampleRepository without touching the UI.
abstract class PaintWalaRepository {
  Future<List<Painter>> painters();
  Future<List<Shop>> shops();
  Future<List<Booking>> bookings();
  Future<List<Quote>> quotes();
  Future<void> addBooking(Booking booking);
  Future<void> addQuote(Quote quote);
  Future<void> addProduct(String shopId, Product product);
  Future<void> setPainterApproved(String painterId, bool approved);
}
