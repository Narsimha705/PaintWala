import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:paintwala/core/l10n.dart';
import 'package:paintwala/core/app_state.dart';
import 'package:paintwala/core/location_service.dart';
import 'package:paintwala/data/sample_repository.dart';
import 'package:paintwala/theme.dart';

class SampleDataBanner extends StatelessWidget {
  const SampleDataBanner({super.key});
  @override
  Widget build(BuildContext context) => Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.orangeSoft,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.orange),
        ),
        child: Row(children: [
          Icon(Icons.info_outline, color: AppColors.orange, size: 20),
          SizedBox(width: 8),
          Expanded(
            child: Text(tr(context, 'Prototype: all names, prices and ratings are SAMPLE data. They are not real people or businesses.'),
              style: TextStyle(fontSize: 12),
            ),
          ),
        ]),
      );
}

Future<void> showAreaPicker(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
            title: Text(tr(context, 'Select your area'),
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          for (final a in sampleAreas)
            ListTile(
              leading: Icon(Icons.place_outlined),
              title: Text(a.name),
              onTap: () {
                appState.setLocation(a.point, a.name);
                Navigator.pop(ctx);
              },
            ),
        ]),
      ),
    );

/// Location + distance filter (2 / 5 / 10 / 20 km).
class LocationFilter extends StatelessWidget {
  const LocationFilter({super.key});

  Future<void> _useGps(BuildContext c) async {
    final ok = await LocationService.requestAndSet(c);
    if (!c.mounted || ok) return;
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(
        content: Text(tr(c, 'Location not shared. Please pick your area manually.'))));
    await showAreaPicker(c);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: appState,
        builder: (context, _) => Card(
          color: Colors.white,
          margin: EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(Icons.location_on, color: AppColors.orange),
                SizedBox(width: 8),
                Expanded(
                  child: Text(appState.label ?? 'Location not set',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ]),
              SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                OutlinedButton.icon(
                    onPressed: () => _useGps(context),
                    icon: Icon(Icons.my_location, size: 18),
                    label: Text(tr(context, 'Use GPS'))),
                OutlinedButton.icon(
                    onPressed: () => showAreaPicker(context),
                    icon: Icon(Icons.edit_location_alt, size: 18),
                    label: Text(tr(context, 'Pick area'))),
              ]),
              SizedBox(height: 12),
              Text(tr(context, 'Distance')),
              Wrap(spacing: 8, children: [
                for (final r in AppState.radii)
                  ChoiceChip(
                    label: Text('$r ${tr(context, 'km')}'),
                    selected: appState.radiusKm == r,
                    selectedColor: AppColors.orange,
                    labelStyle: TextStyle(
                        color: appState.radiusKm == r ? Colors.white : null),
                    onSelected: (_) => appState.setRadius(r),
                  ),
              ]),
            ]),
          ),
        ),
      );
}

class EmptyState extends StatelessWidget {
  final String message;
  const EmptyState(this.message, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.all(32),
        child: Center(child: Text(tr(context, message), textAlign: TextAlign.center)),
      );
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    final color = status == 'Completed'
        ? Colors.green
        : status == 'Confirmed'
            ? AppColors.navy
            : AppColors.orange;
    return Chip(
      label: Text(tr(context, status), style: TextStyle(color: Colors.white, fontSize: 12)),
      backgroundColor: color,
      visualDensity: VisualDensity.compact,
    );
  }
}

String fmtDate(DateTime d) => '${d.day}/${d.month}/${d.year}';

class LanguageButton extends StatelessWidget {
  const LanguageButton({super.key});
  @override
  Widget build(BuildContext context) => PopupMenuButton<String>(
        icon: const Icon(Icons.language),
        tooltip: 'Language',
        onSelected: appState.setLang,
        itemBuilder: (_) => [
          for (final e in supportedLangs.entries)
            PopupMenuItem(value: e.key, child: Text(e.value)),
        ],
      );
}

/// 1234567 -> 12,34,567 (Indian digit grouping)
String fmtRs(int n) {
  final s = n.toString();
  if (s.length <= 3) return s;
  final last3 = s.substring(s.length - 3);
  var rest = s.substring(0, s.length - 3);
  final parts = <String>[];
  while (rest.length > 2) {
    parts.insert(0, rest.substring(rest.length - 2));
    rest = rest.substring(0, rest.length - 2);
  }
  if (rest.isNotEmpty) parts.insert(0, rest);
  return '${parts.join(',')},$last3';
}

/// Rough range from area x painter rate. Estimate only, not a quote.
String estimateText(int sqft, int ratePerSqft) {
  int r100(double v) => (v / 100).round() * 100;
  final lo = r100(sqft * ratePerSqft * 0.9);
  final hi = r100(sqft * ratePerSqft * 1.15);
  return 'Rs ${fmtRs(lo)} - ${fmtRs(hi)}';
}

class EstimateCard extends StatefulWidget {
  final int rate;
  const EstimateCard({super.key, required this.rate});
  @override
  State<EstimateCard> createState() => _EstimateCardState();
}

class _EstimateCardState extends State<EstimateCard> {
  final _c = TextEditingController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sqft = int.tryParse(_c.text) ?? 0;
    return Card(
      color: Colors.white,
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.calculate, color: AppColors.orange),
            const SizedBox(width: 8),
            Text(tr(context, 'Price estimator'),
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 8),
          TextField(
            controller: _c,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: tr(context, 'Area (sq ft)')),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 8),
          Text(
            sqft > 0
                ? '${tr(context, 'Estimated cost')}: ${estimateText(sqft, widget.rate)}'
                : tr(context, 'Enter area to see an estimate.'),
            style: const TextStyle(
                fontWeight: FontWeight.bold, color: AppColors.navy),
          ),
          const SizedBox(height: 4),
          Text(
            tr(context,
                'Estimate only. Final price depends on site visit, paint brand and wall condition.'),
            style: const TextStyle(fontSize: 12),
          ),
        ]),
      ),
    );
  }
}

/// Call + WhatsApp buttons. Sample listings have no phone number,
/// so they show a message instead of dialling anyone.
class ContactButtons extends StatelessWidget {
  final String? phone;
  const ContactButtons({super.key, this.phone});

  Future<void> _open(BuildContext context, bool whatsapp) async {
    final messenger = ScaffoldMessenger.of(context);
    final noPhone =
        tr(context, 'Sample listing: no real phone number to contact.');
    final failed = tr(context, 'Could not open the app.');
    final digits = (phone ?? '').replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) {
      messenger.showSnackBar(SnackBar(content: Text(noPhone)));
      return;
    }
    final full = digits.length == 10 ? '91$digits' : digits;
    final uri =
        whatsapp ? Uri.parse('https://wa.me/$full') : Uri.parse('tel:+$full');
    var ok = false;
    try {
      ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok) messenger.showSnackBar(SnackBar(content: Text(failed)));
  }

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => _open(context, false),
            icon: const Icon(Icons.call),
            label: Text(tr(context, 'Call')),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _open(context, true),
            icon: const Icon(Icons.chat),
            label: Text(tr(context, 'WhatsApp')),
          ),
        ),
      ]);
}
