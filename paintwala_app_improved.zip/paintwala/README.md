# PaintWala — Flutter Android prototype

This is a Flutter prototype for a location-based house-painting marketplace in India.

## Included in this build

- Customer, painter, paint-shop and admin entry screens
- Hyderabad area picker and optional GPS location
- Nearby painter/shop filtering by straight-line distance
- Painter profiles, sample price estimates and service request form
- Booking list, painter quote form and sample shop product list
- English, Telugu and Hindi UI strings
- Android release APK build workflow using GitHub Actions

## Important current limitations

This is **not yet a live marketplace**. The painter/shop names and products are sample data. There is no login, OTP verification, real database, payment gateway, live chat, push notification, or production admin security. Bookings, quotes, shop products and approval changes currently live in app memory and can be lost when the app closes. Do not publish it as a real customer service until a backend and real verified listings are connected.

Customer painter results now show only painters marked approved in the sample repository. This is a prototype filter, not a secure approval system.

## Build an APK from a computer

Install Flutter stable and Android Studio / Android SDK, then run:

```bash
flutter create --platforms=android --project-name=paintwala .
flutter pub get
flutter analyze
flutter build apk --release
```

APK output:

`build/app/outputs/flutter-apk/app-release.apk`

The Android location permissions and `tel` / `https` intent queries must be present in `android/app/src/main/AndroidManifest.xml`. The included GitHub Actions workflow adds them automatically.

## Build an APK using only an Android phone

1. Create or sign in to a GitHub account.
2. Create a new repository named `paintwala`.
3. Upload the contents of this ZIP (the `paintwala` folder contents, not an extra nested folder) to the repository's `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build PaintWala APK** and tap **Run workflow** (or push a commit to `main`).
6. When the workflow completes successfully, open that run and download the `paintwala-release-apk` artifact.
7. Extract the artifact ZIP and install `app-release.apk` on your Android phone. Android may ask you to allow installation from that browser/file manager.

The workflow runs `flutter analyze` before building. If it reports an error, fix the reported source issue before distributing the APK.

## Location permissions

The app requests location only after the user chooses the location option. Android manifest permissions are added by the included build workflow.

## Next work before a public launch

1. Add phone OTP authentication and separate customer/painter/shop accounts.
2. Connect Firebase or Supabase for real listings and persistent bookings.
3. Add painter/shop registration, document verification and secure admin approval.
4. Add booking status updates and notifications.
5. Add privacy policy, terms, support contact and production testing.
6. Add payment only after business, refund and tax flows are decided.
